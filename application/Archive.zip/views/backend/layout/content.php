<?php
include str_replace("system", "application/views/backend/content", BASEPATH)."/$content.php";

 ?>
