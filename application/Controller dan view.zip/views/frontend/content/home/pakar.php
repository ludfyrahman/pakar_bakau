<main class="main-content mt-1 border-radius-lg">
    <div class="container mt-4">
        <!-- <div class="card p-5"> -->
            <img src="<?= base_url('assets/img/pakar/pakar.jpeg') ?>" class='rounded mx-auto d-block' style="width:300px" alt="">
            <h3>Biodata Pakar</h3>
            <table class='table table-striped mt-2'>
                <tr>
                    <td>Nama</td><td>Andi Babasusalam, S.Pt.</td>
                </tr>
                <tr>
                    <td>Tempat, Tanggal lahir</td><td>10 Oktober 1974 di Sumenep, Jawa Timur</td>
                </tr>
            </table>
            <p><?= pakar_description ?></p>
            <div>
                <h3 class='text-center'>Galeri Kandang</h3>
                
            </div>
            <div class="row">
                <div class="col-md-4">
                    <img src="<?= base_url('assets/img/pakar/kandang1.jpeg') ?>" alt="" class="img-fluid">
                </div>
                <div class="col-md-4">
                    <img src="<?= base_url('assets/img/pakar/kandang2.jpeg') ?>" alt="" class="img-fluid">
                </div>
                <div class="col-md-4">
                    <img src="<?= base_url('assets/img/pakar/kandang3.jpeg') ?>" alt="" class="img-fluid">
                </div>
                <div class="col-md-6 mt-2">
                    <img src="<?= base_url('assets/img/pakar/kandang4.jpeg') ?>" alt="" class="img-fluid">
                </div>
                <div class="col-md-6 mt-2">
                    <img src="<?= base_url('assets/img/pakar/kandang5.jpeg') ?>" alt="" class="img-fluid">
                </div>
            </div>
            
        <!-- </div> -->
    </div>
</main>
