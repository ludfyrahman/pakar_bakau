<?php
include str_replace("system", "application/views/frontend/content", BASEPATH)."/$content.php";

 ?>
